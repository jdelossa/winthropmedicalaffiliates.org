<?php


interface Types_Helper_Output_Interface {
	public function set_content( $content );
	public function output();
}