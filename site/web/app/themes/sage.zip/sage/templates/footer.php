<footer class="content-info">
  <div class="container text-right">
    <?php dynamic_sidebar('sidebar-footer'); ?>
  </div>
</footer>
